import xbmcaddon

MainBase = 'http://pastebin.com/raw/JiLCX1YU'
addon = xbmcaddon.Addon('plugin.video.Gospel faith IPTV')